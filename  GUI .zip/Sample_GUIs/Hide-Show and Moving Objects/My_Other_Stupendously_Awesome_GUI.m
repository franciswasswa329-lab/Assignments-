function varargout = My_Other_Stupendously_Awesome_GUI(varargin)
% MY_OTHER_STUPENDOUSLY_AWESOME_GUI MATLAB code for My_Other_Stupendously_Awesome_GUI.fig
%      MY_OTHER_STUPENDOUSLY_AWESOME_GUI, by itself, creates a new MY_OTHER_STUPENDOUSLY_AWESOME_GUI or raises the existing
%      singleton*.
%
%      H = MY_OTHER_STUPENDOUSLY_AWESOME_GUI returns the handle to a new MY_OTHER_STUPENDOUSLY_AWESOME_GUI or the handle to
%      the existing singleton*.
%
%      MY_OTHER_STUPENDOUSLY_AWESOME_GUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in MY_OTHER_STUPENDOUSLY_AWESOME_GUI.M with the given input arguments.
%
%      MY_OTHER_STUPENDOUSLY_AWESOME_GUI('Property','Value',...) creates a new MY_OTHER_STUPENDOUSLY_AWESOME_GUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before My_Other_Stupendously_Awesome_GUI_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to My_Other_Stupendously_Awesome_GUI_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help My_Other_Stupendously_Awesome_GUI

% Last Modified by GUIDE v2.5 17-Apr-2013 07:44:41

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @My_Other_Stupendously_Awesome_GUI_OpeningFcn, ...
                   'gui_OutputFcn',  @My_Other_Stupendously_Awesome_GUI_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before My_Other_Stupendously_Awesome_GUI is made visible.
function My_Other_Stupendously_Awesome_GUI_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to My_Other_Stupendously_Awesome_GUI (see VARARGIN)

% Choose default command line output for My_Other_Stupendously_Awesome_GUI
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes My_Other_Stupendously_Awesome_GUI wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = My_Other_Stupendously_Awesome_GUI_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in Button.
function Button_Callback(hObject, eventdata, handles)
% hObject    handle to Button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
pic = zeros(50,50);                         % black square
axes(handles.axes1)                         % target axis on GUI
imshow(pic);                                % show the black square
set(gca,'XTick',[]);                        % hide the x-axis ticks
set(gca,'YTick',[]);                        % hide the y-axis ticks
set(handles.axes1,'Visible','on');          % make the axis visible
set(handles.stop,'Visible','on');           % make the stop button visible
angle = 45;                                 % start out at an angle of 45 degrees
while ~get(handles.stop,'Value')            % check to see if stop button is pressed
    pos = get(handles.axes1,'Position');    % get current location of the block
    if pos(1) <= 0 || pos(1) >= 300 || pos(2) <= 0 || pos(2) >= 200 % check to see if the block has reached a boundary
        angle = bounce(angle,handles);      % if it is at a boundary, bounce off
    end
    set(handles.axes1,'Position',[(pos(1) + 2*cosd(angle)) (pos(2) + 2*sind(angle)) pos(3) pos(4)]); % update position of block
    pause(0.01);                            % pause to allow for animation to show
end
set(handles.stop,'Value',0);                % set stop button back to 0
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% User-defined function to determine new angle upon hitting a wall
function angle = bounce(angle,handles)
pos = get(handles.axes1,'Position');
if (pos(1) <= 0 && angle < 0)
    angle = angle + 90;
elseif (pos(1) <= 0 && angle > 0)
    angle = angle - 90;
elseif (pos(1) >= 300 && angle > 0)
    angle = angle + 90;
elseif (pos(1) >= 300 && angle < 0)
    angle = angle - 90;
elseif (pos(2) <= 0 && angle < -90)
    angle = angle + 270;
elseif (pos(2) <= 0 && angle > -90)
    angle = angle + 90;
elseif (pos(2) >= 200 && angle < 90)
    angle = angle - 90;
else
    angle = angle - 270;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% --- Executes on button press in stop.
function stop_Callback(hObject, eventdata, handles)
% hObject    handle to stop (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of stop
