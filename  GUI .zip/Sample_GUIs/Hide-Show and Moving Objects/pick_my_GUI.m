function pick_my_GUI()
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% pick_my_GUI allows you to choose which of the two GUI's,
% My_Stupendously_Awesome_GUI or My_Other_Stupendously_Awesome_GUI to run.
%
% My_Stupendously_Awesome_GUI demonstrates how to show/hide objects on the
% GUI
% My_Other_Stupendously_Awesome_GUI demonstrates how to create animations
% by moving an object around the GUI
% pick_my_GUI demonstrates how to open a GUI from a script/function/GUI
%
% "You can pick your friends, and you can pick your GUI, but you can't pick
% your friend's GUI."
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

choice = menu('Please select your GUI:','My Stupendously Awesome GUI (show/hide)','My Other Stupendously Awesome GUI (animation)');
switch choice
    case 1
        My_Stupendously_Awesome_GUI;
    case 2
        My_Other_Stupendously_Awesome_GUI;
end

end