function varargout = Table_Test(varargin)
% TABLE_TEST MATLAB code for Table_Test.fig
%      TABLE_TEST, by itself, creates a new TABLE_TEST or raises the existing
%      singleton*.
%
%      H = TABLE_TEST returns the handle to a new TABLE_TEST or the handle to
%      the existing singleton*.
%
%      TABLE_TEST('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in TABLE_TEST.M with the given input arguments.
%
%      TABLE_TEST('Property','Value',...) creates a new TABLE_TEST or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Table_Test_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Table_Test_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Table_Test

% Last Modified by GUIDE v2.5 11-Mar-2013 11:47:23

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Table_Test_OpeningFcn, ...
                   'gui_OutputFcn',  @Table_Test_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Table_Test is made visible.
function Table_Test_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Table_Test (see VARARGIN)

% Choose default command line output for Table_Test
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes Table_Test wait for user response (see UIRESUME)
% uiwait(handles.figure1);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% store initial values into table
for k = 1:4
    for m = 1:4
        vals{k,m} = 4*(k-1)+m;
    end
end
set(handles.Tab_Values,'Data',vals);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% --- Outputs from this function are returned to the command line.
function varargout = Table_Test_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function Row_Value_Callback(hObject, eventdata, handles)
% hObject    handle to Row_Value (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Row_Value as text
%        str2double(get(hObject,'String')) returns contents of Row_Value as a double


% --- Executes during object creation, after setting all properties.
function Row_Value_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Row_Value (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Col_Value_Callback(hObject, eventdata, handles)
% hObject    handle to Col_Value (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Col_Value as text
%        str2double(get(hObject,'String')) returns contents of Col_Value as a double


% --- Executes during object creation, after setting all properties.
function Col_Value_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Col_Value (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Val_Value_Callback(hObject, eventdata, handles)
% hObject    handle to Val_Value (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Val_Value as text
%        str2double(get(hObject,'String')) returns contents of Val_Value as a double


% --- Executes during object creation, after setting all properties.
function Val_Value_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Val_Value (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in Enter.
function Enter_Callback(hObject, eventdata, handles)
% hObject    handle to Enter (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% get values from text boxes
row = str2double(get(handles.Row_Value,'String'));
col = str2double(get(handles.Col_Value,'String'));
val = str2double(get(handles.Val_Value,'String'));
% ensure everthing is in proper order
if (isnan(row) || isnan(col) || isnan(val)) || (row < 1 || col < 1 || col > 4 || row > 4)
    msgbox('One of the values you entered is not correct.  Please try again.');
else
    % get the table values, update, and replace
    val_array = get(handles.Tab_Values,'Data');
    val_array{row, col} = val;
    set(handles.Tab_Values,'Data',val_array);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


function Get_Row_Callback(hObject, eventdata, handles)
% hObject    handle to Get_Row (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Get_Row as text
%        str2double(get(hObject,'String')) returns contents of Get_Row as a double


% --- Executes during object creation, after setting all properties.
function Get_Row_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Get_Row (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Get_Col_Callback(hObject, eventdata, handles)
% hObject    handle to Get_Col (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Get_Col as text
%        str2double(get(hObject,'String')) returns contents of Get_Col as a double


% --- Executes during object creation, after setting all properties.
function Get_Col_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Get_Col (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Value_tab_Callback(hObject, eventdata, handles)
% hObject    handle to Value_tab (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Value_tab as text
%        str2double(get(hObject,'String')) returns contents of Value_tab as a double


% --- Executes during object creation, after setting all properties.
function Value_tab_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Value_tab (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in Get_Value.
function Get_Value_Callback(hObject, eventdata, handles)
% hObject    handle to Get_Value (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
row = str2double(get(handles.Get_Row,'String'));
col = str2double(get(handles.Get_Col,'String'));
% ensure everthing is in proper order
if (isnan(row) || isnan(col)) || (row < 1 || col < 1 || col > 4 || row > 4)
    msgbox('One of the values you entered is not correct.  Please try again.');
else
    % get the table values, update, and replace
    val_array = get(handles.Tab_Values,'Data');
    val = val_array{row, col};
    set(handles.Value_tab,'String',val);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%